export interface IOrder {
  name: string;
  price: string;
  quantity: string;
  dateCreated: string;
}
