import LoginModal from './LoginModal';

export default LoginModal;
